from django.apps import AppConfig


class AppBbsConfig(AppConfig):
    name = 'app_bbs'
