from django.contrib import admin
from app_bbs import models

# Register your models here.


admin.site.register(models.UserInfo)
admin.site.register(models.Blog)
admin.site.register(models.Tag)
admin.site.register(models.Article)
admin.site.register(models.Up_down)
admin.site.register(models.Category)
admin.site.register(models.Comment)
admin.site.register(models.Article_tag)
