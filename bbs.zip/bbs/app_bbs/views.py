import json

from django.contrib import auth
from django.db import transaction
from django.shortcuts import render, HttpResponse, redirect
from PIL import Image, ImageDraw, ImageFont
import random
from io import BytesIO
from app_bbs import models
from django.http import JsonResponse
# Create your views here.
from app_bbs.my_forms import MyRegForms
from django.contrib.auth.decorators import login_required
from django.db.models import Count, F
from django.db.models.functions import TruncMonth


def register(request):
    forms_obj = MyRegForms()
    if request.method == 'POST':
        back_dic = {'code': 101, 'msg': ''}
        forms_obj = MyRegForms(request.POST)
        if forms_obj.is_valid():
            clean_data = forms_obj.cleaned_data
            clean_data.pop('confirm_password')
            file_obj = request.FILES.get('avatar')
            if file_obj:
                clean_data['avatar'] = file_obj
            models.UserInfo.objects.create_user(**clean_data)
            back_dic['url'] = '/login/'
        else:
            back_dic['code'] = 100
            back_dic['msg'] = forms_obj.errors
        return JsonResponse(back_dic)

    return render(request, 'register.html', locals())


def login(request):
    if request.method == 'POST':
        back_dic = {'code': 101, 'msg': ''}
        username = request.POST.get('username')
        password = request.POST.get('password')
        auth_code = request.POST.get('auth_code')
        # 先校验验证码
        if request.session.get('auth_code') == auth_code:
            user_obj = auth.authenticate(request, username=username, password=password)
            if user_obj:
                auth.login(request, user_obj)
                back_dic['url'] = '/home/'
            else:
                back_dic['code'] = 100
                back_dic['msg'] = '用户名或密码错误'
        else:
            back_dic['code'] = 99
            back_dic['msg'] = '验证码错误'
        return JsonResponse(back_dic)
    return render(request, 'login.html')


def home(request):
    article_queryset = models.Article.objects.all()
    return render(request, 'home.html', locals())


def site(request, username, **kwargs):
    user_obj = models.UserInfo.objects.filter(username=username).first()
    if not user_obj:
        return render(request, 'errors.html')
    blog = user_obj.blog
    article_list = models.Article.objects.filter(blog=blog)
    if kwargs:
        condition = kwargs.get('condition')
        param = kwargs.get('param')
        if condition == 'category':
            article_list = article_list.filter(category_id=param)
        elif condition == 'tag':
            article_list = article_list.filter(tag__id=param)
        else:
            year, month = param.split('-')
            article_list = article_list.filter(create_time__year=year, create_time__month=month)
    category_list = models.Category.objects.filter(blog=blog).annotate(count_num=Count('article__pk')).values_list(
        'name', 'count_num', 'pk')
    tag_list = models.Tag.objects.filter(blog=blog).annotate(count_num=Count('article__pk')).values_list('name',
                                                                                                         'count_num',
                                                                                                         'pk')
    data_list = models.Article.objects.filter(blog=blog).annotate(month=TruncMonth('create_time')).values(
        'month').annotate(count_num=Count('pk')).values_list('month', 'count_num')
    return render(request, 'site.html', locals())


def article_detail(request, username, article_id):
    user_obj = models.UserInfo.objects.filter(username=username).first()
    blog = user_obj.blog
    article_obj = models.Article.objects.filter(pk=article_id, blog__userinfo__username=username).first()

    if not article_obj:
        return render(request, 'errors.html')
    comment_list = models.Comment.objects.filter(article=article_obj)
    return render(request, 'article.html', locals())


@login_required()
def modify_pwd(request):
    if request.is_ajax():
        back_dic = {'code': 101, 'msg': ''}
        if request.method == 'POST':
            old_password = request.POST.get('old_password')
            new_password = request.POST.get('new_password')
            confirm_password = request.POST.get('confirm_password')
            is_right = request.user.check_password(old_password)
            if is_right:
                if new_password == confirm_password:
                    request.user.set_password(new_password)
                    request.user.save()
                    back_dic['msg'] = '修改成功'
                else:
                    back_dic['code'] = 100
                    back_dic['msg'] = '两次密码不一致'
            else:
                back_dic['code'] = 99
                back_dic['msg'] = '原密码不正确'
        return JsonResponse(back_dic)


def logout(request):
    auth.logout(request)
    return redirect('/home/')


'''
pillow模块，用来处理图片相关
from PIL import Image, ImageDraw, ImageFont
Image:生成图片
ImageDraw:在图片上操作
ImageFont:控制字体样式

from io import BytesIO, StringIO
内存管理器模块
BytesIO：临时存储数据，返回时数据是二进制格式
StringIO：临时存储数据，返回时数据是字符串形式
'''


def get_random():
    return random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)


def get_code(request):
    # 利用PIL模块动态生成图片
    img_obj = Image.new(mode='RGB', size=(290, 35), color=get_random())
    img_draw = ImageDraw.Draw(img_obj)  # 生成一个画笔对象
    img_font = ImageFont.truetype('static/font/1.ttf', 30)  # 字体样式和大小
    # 产生随机验证码
    auth_code = ''
    for i in range(4):
        random_int = str(random.randint(0, 9))
        # 将随机产生到数字写到图片上
        img_draw.text((30 + i * 60, -2), random_int, get_random(), img_font)
        auth_code = auth_code + random_int
    request.session['auth_code'] = auth_code
    io_obj = BytesIO()  # 生成一个内存管理器
    img_obj.save(io_obj, 'png')
    return HttpResponse(io_obj.getvalue())  # 从内存管理器中读取图片


def up_and_down(request):
    if request.is_ajax():
        back_dic = {'code': 100, 'msg': ''}
        if request.user.is_authenticated():
            article_id = request.POST.get('article_id')
            is_up = request.POST.get("is_up")
            is_up = json.loads(is_up)
            article_obj = models.Article.objects.filter(pk=article_id).first()
            if not article_obj.blog.userinfo == request.user:
                is_click = models.Up_down.objects.filter(user=request.user, article=article_obj)
                if not is_click:
                    if is_up:
                        models.Article.objects.filter(pk=article_id).update(up_num=F('up_num') + 1)
                        back_dic['msg'] = '点赞成功'
                    else:
                        models.Article.objects.filter(pk=article_id).update(down_num=F('down_num') + 1)
                        back_dic['msg'] = '反对成功'
                    models.Up_down.objects.create(user=request.user, article=article_obj, is_up=is_up)
                else:
                    back_dic['code'] = 99
                    back_dic['msg'] = '你已经点过了'
            else:
                back_dic['code'] = 98
                back_dic['msg'] = '不能给自己点'
        else:
            back_dic['code'] = 97
            back_dic['msg'] = '请先<a href="/login/">登陆</a>'
        return JsonResponse(back_dic)


def comment(request):
    if request.is_ajax():
        back_dic = {'code': 100, 'msg': ''}
        if request.method == 'POST':
            if request.user.is_authenticated():
                article_id = request.POST.get('article_id')
                content = request.POST.get('content')
                models.Article.objects.filter(pk=article_id).update(comment_num=F('comment_num') + 1)
                models.Comment.objects.create(user=request.user, article_id=article_id, content=content)
                back_dic['msg'] = '发表成功'
        return JsonResponse(back_dic)


@login_required
def backend(request):
    article_list = models.Article.objects.filter(blog=request.user.blog)
    return render(request, 'backend.html', locals())


from bs4 import BeautifulSoup


@login_required()
def add_article(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        content = request.POST.get('content')
        category_id = request.POST.get('category')
        tag_id_list = request.POST.getList('tag')
        soup = BeautifulSoup(content, 'html.parser')
        tags = soup.find_all()
        for tag in tags:
            if tag == 'script':
                tag.decompose()
        desc = soup.text[0:150]

        article_obj = models.Article.objects.create(
            title=title,
            content=str(soup),
            category_id=category_id,
            desc=desc,
            blog=request.user.blog
        )
        article_obj_list = []
        for i in tag_id_list:
            tag_article_obj = models.Article_tag(article=article_obj, tag_id=i)
            article_obj_list.append(tag_article_obj)
        models.Article_tag.objects.bulk_create(article_obj_list)
        return redirect('/backend/')

    category_list = models.Category.objects.filter(blog=request.user.blog)
    tag_list = models.Tag.objects.filter(blog=request.user.blog)
    return render(request, 'add_article.html', locals())
