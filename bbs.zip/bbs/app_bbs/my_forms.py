from django import forms
from app_bbs import models


# 注册功能forms组件代码
class MyRegForms(forms.Form):
    username = forms.CharField(max_length=8, min_length=3, label='账号', error_messages={
        'max_length': '用户名最大八位',
        'min_length': '用户名最小八位',
        'required': '用户名不能为空'
    }, widget=forms.widgets.TextInput(attrs={'class': 'form-control'}))
    password = forms.CharField(max_length=8, min_length=3, label='密码', error_messages={
        'max_length': '密码最大八位',
        'min_length': '密码最小八位',
        'required': '密码不能为空'
    }, widget=forms.widgets.PasswordInput(attrs={'class': 'form-control'}))
    confirm_password = forms.CharField(max_length=8, min_length=3, label='确认密码', error_messages={
        'max_length': '确认密码最大八位',
        'min_length': '确认密码最小八位',
        'required': '确认密码不能为空'
    }, widget=forms.widgets.PasswordInput(attrs={'class': 'form-control'}))
    email = forms.EmailField(label='邮箱', error_messages={
        'invalid': '邮箱无效',
        'required': '邮箱不能为空'
    }, widget=forms.widgets.EmailInput(attrs={'class': 'form-control'}))

    # 局部钩子，校验用户名是否存在
    def clean_username(self):
        username = self.cleaned_data.get('username')
        # 去数据库中判断是否存在
        is_exist = models.UserInfo.objects.filter(username=username)
        if is_exist:
            self.add_error('username', '用户名也存在')
        return username

    # 全局钩子校验，两次密码是否一致
    def clean(self):
        password = self.cleaned_data.get('password')
        confirm_password = self.cleaned_data.get('confirm_password')
        if not confirm_password == password:
            self.add_error('confirm_password', '两次密码不一致')
        return self.cleaned_data
